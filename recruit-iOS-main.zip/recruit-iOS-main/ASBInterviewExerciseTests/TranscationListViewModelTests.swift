//
//  TranscationListViewModelTests.swift
//  ASBInterviewExerciseTests
//
//  Created by Ethan on 2021/10/20.
//


import XCTest
@testable import ASBInterviewExercise

class TranscationListViewModelTests: XCTestCase {
    
    var testDataProvider: TestDataProvider!
    var networkingProvider: MockNetworkProvider!

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        testDataProvider = TestDataProvider(withFileName: "data.json")
        networkingProvider = MockNetworkProvider(withDataProvider: testDataProvider)
    }
    
    func testgetTranscations() throws {
        let viewModel = TranscationListViewModel(interactor: networkingProvider!)
        let getTranscationsExpectation = self.expectation(description: "Get Transcations Expectation")
        var transcations: [Transcation]?

        viewModel.getTranscations {
            debugPrint("failed")
            XCTAssertTrue(false)
        } completion: { (items) in
            transcations = items
            getTranscationsExpectation.fulfill()
            transcations?.forEach { (Transcation) in
                debugPrint(Transcation.summary)
            }
        }
        self.waitForExpectations(timeout: 0.1) { (error) in
            guard error == nil else {
                XCTFail("Expectation error: \(String(describing: error?.localizedDescription))")
                return
            }
            XCTAssertNotNil(transcations)
            XCTAssertTrue(transcations?.count == 19)
        }
    }
}
