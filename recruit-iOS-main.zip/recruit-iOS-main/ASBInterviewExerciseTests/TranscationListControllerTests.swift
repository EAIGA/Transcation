//
//  TranscationListControllerTests.swift
//  ASBInterviewExerciseTests
//
//  Created by Ethan on 2021/10/20.
//

import XCTest
@testable import ASBInterviewExercise

class TranscationListControllerTests: XCTestCase {
    
    var viewModel: TranscationListProtocols?
    var testDataProvider: TestDataProvider!
    var networkingProvider: MockNetworkProvider!
    
    override func setUpWithError() throws {
        testDataProvider = TestDataProvider(withFileName: "data.json")
        networkingProvider = MockNetworkProvider(withDataProvider: testDataProvider)
    }

    func testLoadData() {
        let viewModel = TranscationListViewModel(interactor: networkingProvider!)
        let expectation = XCTestExpectation(description:  "testLoadData")
        viewModel.getTranscations(){
            debugPrint("failed")
            XCTAssertTrue(false)
        } completion: {_ in
            expectation.fulfill()
            XCTAssertNotNil(viewModel.transcations)
            XCTAssertEqual(viewModel.transcations?.count, 19)
        }
    }
    
}
