//
//  TranscationDetailControllerTests.swift
//  ASBInterviewExerciseTests
//
//  Created by Ethan on 2021/10/20.
//

import XCTest
@testable import ASBInterviewExercise

class TranscationDetailControllerTests: XCTestCase {
    
    var testDataProvider: TestDataProvider!

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        testDataProvider = TestDataProvider(withFileName: "data.json")
    }
    
    func testBuildController() {
        let transcationData =  testDataProvider.dataRepresentation
        let responseParser = ResponseParser(data: transcationData!)
        if let decoded = responseParser.decode([Transcation].self){
            let vc = TranscationDetailController(transcation: decoded[0])
            XCTAssertNotNil(vc);
            XCTAssertTrue(vc.view.subviews.count > 0);
        }
    }
    
}
