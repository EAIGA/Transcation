//
//  TranscationTests.swift
//  ASBInterviewExerciseTests
//
//  Created by Ethan on 2021/10/20.
//

import XCTest
@testable import ASBInterviewExercise

class TranscationTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testTranscation() throws {
        let transcation = Transcation(id: "100", summary: "test Transcation", debit: Decimal(115.0), credit: Decimal(0))
        XCTAssertEqual(transcation.amountText, "-$115.00")
        XCTAssertEqual(transcation.summary, "test Transcation")
        XCTAssertEqual(transcation.gst, 15)
    }

}
