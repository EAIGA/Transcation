//
//  TestDataProvider.swift
//  ASBInterviewExerciseTests
//
//  Created by Ethan on 2021/10/20.
//

import XCTest
@testable import ASBInterviewExercise

class MockNetworkProvider: NetworkingProtocol {
    
    private let dataProvider: TestDataProvider
    
    required init(withDataProvider dataProvider: TestDataProvider) {
        self.dataProvider = dataProvider
    }
    
    // MARK: NetworkingProviderProtocol
    func getRequest(urlString: String, onCompleted: ((Data?, URLResponse?, Error?) -> ())?) {
        onCompleted?(self.dataProvider.dataRepresentation, nil, nil)
    }

}

class TestDataProvider {
    
    private let fileName: NSString
    
    var dataRepresentation: Data? {
        get {
            let testBundle = Bundle(for: type(of: self))
            let filePath = testBundle.path(forResource: fileName.deletingPathExtension, ofType: fileName.pathExtension)
            
            if let path = filePath {
                let result = FileManager.default.contents(atPath: path)
                return result
            }
            return nil
        }
    }
    
    var jsonRepresentation: Any? {
        get {
            guard
                let data = dataRepresentation,
                let jsonObject = try? JSONSerialization.jsonObject(with: data, options: [JSONSerialization.ReadingOptions.allowFragments]) else {
                return nil
            }
            return jsonObject
        }
    }
    
    required init(withFileName fileName: String) {
        self.fileName = fileName as NSString
    }
    
}

class ResponseParser {
    
    private var data: Data
    
    init(data: Data) {
        self.data = data
    }
    
    func decode<T: Codable>(_ type: T.Type) -> T? {
        let jsonDecoder = JSONDecoder()
        jsonDecoder.dateDecodingStrategy = .iso8601
        
        do {
            let response = try jsonDecoder.decode(T.self, from: data)
            return response
        } catch let error {
            debugPrint(error)
            return nil
        }
    }
    
}
