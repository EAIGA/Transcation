//
//  TranscationUITests.swift
//  ASBInterviewExerciseUITests
//
//  Created by Ethan on 2021/10/20.
//

import XCTest
@testable import ASBInterviewExercise

class TranscationUITests: XCTestCase {
    let app = XCUIApplication()
    
    override func setUpWithError() throws {
        continueAfterFailure = false
        app.launch()
    }

    override func tearDownWithError() throws {
        app.terminate()
    }
    
    func testEntryValidView() {
        let navigationBar: XCUIElement = app.staticTexts["TranscationList"]
        XCTAssertNotNil(navigationBar)
        let table: XCUIElement = self.app.tables.firstMatch
        XCTAssertNotNil(table.cells)
        
        let title: XCUIElement = app.statusItems["Fancy Food Market Auckland"]
        XCTAssertNotNil(title)
        table.cells.statusItems["Fancy Food Market Auckland"].tap()
        sleep(1)
        
        app.navigationBars["Transcation Detai"].buttons["Transcation Detai"].tap()
        XCTAssertTrue(self.app.tables.firstMatch.exists)
        self.app.swipeUp()
    }
}
