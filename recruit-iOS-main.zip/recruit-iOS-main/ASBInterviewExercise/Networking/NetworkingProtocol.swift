//
//  NetworkingProtocol.swift
//  ASBInterviewExercise
//
//  Created by Ethan on 2021/10/19.
//

import Foundation

protocol NetworkingProtocol {
    
    func getRequest(urlString: String, onCompleted: ((Data?, URLResponse?, Error?) -> ())?)
    
}

enum HttpMethod: String {
    
    case GET = "GET"
    case POST = "POST"
    case PUT = "PUT"
    
}

extension NetworkingProtocol {
    
    func defaultRequest(urlString: String, httpMethod: String = HttpMethod.GET.rawValue) -> URLRequest? {
        guard !urlString.isEmpty, let endpointUrl = URL(string: urlString) else { return nil }
        var request = URLRequest(url: endpointUrl)
        request.httpMethod = httpMethod
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        return request
    }
    
}
