//
//  ApiUriManager.swift
//  ASBInterviewExercise
//
//  Created by Ethan on 2021/10/19.
//

import Foundation

protocol EndpointType {
    
    var baseURL: URL { get }
    var path: String { get }
}

enum ApiUriManager {
    case transactions
        //https://60220907ae8f8700177dee68.mockapi.io/api/v1/transactions
}

extension ApiUriManager: EndpointType {
    var baseURL: URL {
        return URL(string: "https://60220907ae8f8700177dee68.mockapi.io")!
    }
    
    var path: String {
        switch self {
        case .transactions:
            return "/api/v1/transactions"
        }
    }
    
    var fullUrlString: String? {
        switch self {
        case .transactions:
            return baseURL.appendingPathComponent(path).absoluteString.removingPercentEncoding
        }
    }
    
}
