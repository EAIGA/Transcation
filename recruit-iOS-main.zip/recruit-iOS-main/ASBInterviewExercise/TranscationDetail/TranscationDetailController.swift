//
//  TranscationDetailController.swift
//  ASBInterviewExercise
//
//  Created by Ethan on 2021/10/19.
//

import UIKit
import TinyConstraints

class TranscationDetailController: ViewController {
    
    //MARK: -- Vars
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = .boldSystemFont(ofSize: 23)
        label.numberOfLines = 1
        label.textAlignment = .center
        label.textColor = .black
        self.view.addSubview(label)
        label.edgesToSuperview(excluding: [ .bottom], insets: .init(top: 100, left: 10, bottom: 0, right: 10))
        label.height(50)
        return label
    }()

    lazy var amountLabel: UILabel = {
        let label = UILabel()
        label.font = .boldSystemFont(ofSize: 20)
        label.numberOfLines = 1
        label.textAlignment = .center
        label.textColor = .red
        self.view.addSubview(label)
        label.edgesToSuperview(excluding: [ .bottom], insets: .init(top: 150, left: 10, bottom: 0, right: 10))
        label.height(30)
        return label
    }()
    
    lazy var gstLabel: UILabel = {
        let label = UILabel()
        label.font = .boldSystemFont(ofSize: 18)
        label.numberOfLines = 1
        label.textAlignment = .center
        label.textColor = .blue
        self.view.addSubview(label)
        label.edgesToSuperview(excluding: [ .bottom], insets: .init(top: 200, left: 10, bottom: 0, right: 10))
        label.height(30)
        return label
    }()
    
    lazy var timeLabel: UILabel = {
        let label = UILabel()
        label.font = .boldSystemFont(ofSize: 15)
        label.numberOfLines = 1
        label.textAlignment = .center
        label.textColor = .gray
        self.view.addSubview(label)
        label.edgesToSuperview(excluding: [ .bottom], insets: .init(top: 260, left: 10, bottom: 0, right: 10))
        label.height(30)
        return label
    }()
    
    //MARK: -- Inits
    convenience init() {
        self.init(nibName:nil, bundle:nil)

    }
    
    convenience init(transcation: Transcation) {
        self.init(nibName:nil, bundle:nil)
        
        self.titleLabel.text = transcation.summary
        self.amountLabel.text = transcation.amountText
        self.gstLabel.text = "GST: \(transcation.gstText)"
        self.timeLabel.text = transcation.dateText
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
        self.title = "Transcation Detail"
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
}
