//
//  TranscationListCell.swift
//  ASBInterviewExercise
//
//  Created by Ethan on 2021/10/19.
//

import UIKit
import TinyConstraints

class TranscationListCell: UITableViewCell {
    
    //MARK: -- Vars
    static let identifier = "TranscationListCell"
    
    lazy var summaryLabel: UILabel = {
        let label = UILabel()
        label.font = .boldSystemFont(ofSize: 16)
        label.numberOfLines = 2
        label.textAlignment = .left
        label.textColor = .black
        self.contentView.addSubview(label)
        return label
    }()
    
    lazy var dateLabel: UILabel = {
        let label = UILabel()
        label.font = .boldSystemFont(ofSize: 15)
        label.numberOfLines = 1
        label.textAlignment = .left
        label.textColor = .gray
        self.contentView.addSubview(label)
        return label
    }()
    
    lazy var amountLabel: UILabel = {
        let label = UILabel()
        label.font = .boldSystemFont(ofSize: 15)
        label.numberOfLines = 1
        label.textAlignment = .center
        label.textColor = .red
        self.contentView.addSubview(label)
        return label
    }()
    
    //MARK: -- Inits
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.selectionStyle = .none
        summaryLabel.edgesToSuperview(insets: .init(top: 10, left: 20, bottom: 30, right: 50))
        dateLabel.edgesToSuperview(insets: .init(top: 70, left: 20, bottom: 0, right: 50))
        amountLabel.edgesToSuperview(excluding: [ .left,.bottom], insets: .init(top: 30, left: 10, bottom: 0, right: 10))

    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    //MARK: -- Config cell contents
    
    func configCellWith(model: TranscationListCellViewModel) {
        summaryLabel.text = model.summary
        dateLabel.text = model.dateTime
        amountLabel.text = model.amount
    }
    
}
