//
//  TranscationListCellViewModel.swift
//  ASBInterviewExercise
//
//  Created by Ethan on 2021/10/20.
//

import UIKit

struct TranscationListCellViewModel {
    
    let id: String
    let dateTime: String
    let summary: String
    let amount: String
    
    init(with transcation: Transcation) {
        self.id = transcation.id
        self.dateTime =  transcation.dateText
        self.summary = transcation.summary
        self.amount = transcation.amountText
    }

}
