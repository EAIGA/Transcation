//
//  Transcation.swift
//  ASBInterviewExercise
//
//  Created by Ethan on 2021/10/19.
//

import Foundation

struct Transcation: Codable {
    
    let id: String
    let dateTime: Date
    let summary: String
    let debit: Decimal
    let credit: Decimal
    
    enum CodingKeys: String, CodingKey {
        case id
        case dateTime = "transactionDate"
        case summary
        case debit
        case credit
    }
    
    init(id: String, dateTime: Date = Date(), summary: String, debit: Decimal, credit: Decimal) {
        self.id = id
        self.dateTime =  dateTime
        self.summary = summary
        self.debit = debit
        self.credit = credit
    }
    
    
    init(from decoder: Decoder) throws {
        let keys = try decoder.container(keyedBy: CodingKeys.self)
        id = try keys.decodeIfPresent(String.self, forKey: .id) ?? "0"
        dateTime = try keys.decodeIfPresent(Date.self, forKey: .dateTime) ?? Date()
        summary = try keys.decodeIfPresent(String.self, forKey: .summary) ?? "N/A"
        debit = Decimal(try keys.decodeIfPresent(Double.self, forKey: .debit) ?? 0.0)
        credit = Decimal(try keys.decodeIfPresent(Double.self, forKey: .credit) ?? 0.0)
    }
    
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(dateTime, forKey: .dateTime)
        try container.encode(summary, forKey: .summary)
        try container.encode(debit, forKey: .debit)
        try container.encode(credit, forKey: .credit)
    }
    
}

extension Transcation {

    var isDebit: Bool { return debit > 0 }
    var isCredit: Bool { return credit > 0 }
    var dateText: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm, E d MMM y"
        formatter.timeZone = TimeZone.current
        return formatter.string(from: self.dateTime)
    }
    var amountText: String {
        if isDebit {
            return "-\(formatterString(decimal: debit) ?? "")"
        } else if isCredit {
            return "+\(formatterString(decimal: credit) ?? "")"
        } else {
            return ""
        }
    }

    var gst: Decimal {
        let priceDecimalNumber = NSDecimalNumber(decimal: (isDebit ? debit : credit))
        let taxPercentage = NSDecimalNumber(string: "1.15") // 15%
        let tax = priceDecimalNumber.subtracting(priceDecimalNumber.dividing(by: taxPercentage))
        return tax.decimalValue
    }

    var gstText: String {
        return formatterString(decimal: gst) ?? ""
    }

    func formatterString(decimal: Decimal) -> String? {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale(identifier: "en_NZ")
        return formatter.string(for: decimal)
    }
}
