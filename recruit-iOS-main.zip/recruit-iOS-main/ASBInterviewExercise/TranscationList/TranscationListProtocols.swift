//
//  TranscationListProtocols.swift
//  ASBInterviewExercise
//
//  Created by Ethan on 2021/10/19.
//

import UIKit

protocol TranscationListProtocols {
    
    var transcations: [Transcation]? { get }
    func getTranscations(failure:(() -> Void)?, completion: ((_ response: [Transcation]) -> Void)?)
    func selectedTranscation(at index: Int) -> Transcation
    
}
