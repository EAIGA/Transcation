//
//  TranscationListController.swift
//  ASBInterviewExercise
//
//  Created by Ethan on 2021/10/19.
//

import UIKit
import TinyConstraints
import JGProgressHUD

class TranscationListController: ViewController {
    
    // MARK: - Properties
    var viewModel: TranscationListProtocols?
    private let cellHeight: CGFloat = 90

    //MARK: -- Vars
    lazy var tableView: UITableView = {
        let view = UITableView.init(frame: .zero, style: .plain)
        view.backgroundColor = UIColor.clear
        view.delegate = self
        view.dataSource = self
        view.register(TranscationListCell.self, forCellReuseIdentifier: TranscationListCell.identifier)
        return view
    }()

    //MARK: -- Inits
    convenience init() {
        self.init(nibName:nil, bundle:nil)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
        self.title = "TranscationList"
        // add loading
        showLoadingHUD()
        //get data
        setupviewModel()
        setupTableView()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }

    ///Initialises the tableview
    func setupTableView() {
        //add tableview
        self.view.addSubview(tableView)
        tableView.edgesToSuperview()
    }
    
    private func setupviewModel() {
        viewModel = DIManager.shared.resolve(type: TranscationListProtocols.self, named: "TranscationListProtocols")!
        viewModel?.getTranscations(){
    
        } completion: {[weak self] _ in
            DispatchQueue.main.async {
                self?.hideLoadingHUD()
                self?.tableView.reloadData()
            }
        }
    }
    
}

extension TranscationListController: UITableViewDelegate, UITableViewDataSource {

    //MARK: -- TableView Delegates.
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel?.transcations?.count ?? 1
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return cellHeight
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let transcation: Transcation = self.viewModel?.transcations?[indexPath.row] {
            let viewModel = TranscationListCellViewModel.init(with: transcation)
            let cell = tableView.dequeueReusableCell(withIdentifier: TranscationListCell.identifier, for: indexPath) as! TranscationListCell
            cell.configCellWith(model: viewModel)

            return cell
        }else{
            return UITableViewCell()
        }
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)

        if let transcation = self.viewModel?.selectedTranscation(at: indexPath.row){
            let vc = TranscationDetailController(transcation: transcation)
            self.navigationController?.pushViewController(vc, animated: true)
        }

        return
    }

}

extension TranscationListController {
    
    private func showLoadingHUD() {
        let hud = JGProgressHUD()
        hud.textLabel.text = "Loading..."
        hud.shadow = JGProgressHUDShadow(color: .black, offset: .zero, radius: 5.0, opacity: 0.2)
        hud.show(in: self.view)
    }

    private func hideLoadingHUD() {
        if let hub = view.subviews.filter({ $0.isKind(of: JGProgressHUD.self) }).first as? JGProgressHUD {
            hub.dismiss(afterDelay: 1, animated: true)
        }
    }
    
}
