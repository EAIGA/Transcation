//
//  TranscationListViewModel.swift
//  ASBInterviewExercise
//
//  Created by Ethan on 2021/10/19.
//
import Alamofire

final class TranscationListViewModel: TranscationListProtocols {
    
    // MARK: - Properties
    var transcations: [Transcation]?
    
    // MARK: - Dependencies
    private let interactor: NetworkingProtocol

    // MARK: - Initializers
    init(interactor: NetworkingProtocol) {
        self.interactor = interactor
    }
    
    func getTranscations(failure:(() -> Void)?, completion: ((_ response: [Transcation]) -> Void)?) {
        guard let urlString = ApiUriManager.transactions.fullUrlString else {
            debugPrint("transactions url is nil")
            failure?()
            return
        }
        
        self.interactor.getRequest(urlString: urlString) { [weak self] data, response, error  in
            if let _ = error {
                debugPrint(error ?? "error")
                failure?()
                return
            }
            
            guard let responseData = data else {
                debugPrint(error ?? "error")
                failure?()
                return
            }
            
            let jsonDecoder = JSONDecoder()
            jsonDecoder.dateDecodingStrategy = .iso8601
            do{
                let transcations = try jsonDecoder.decode([Transcation].self, from: responseData)
                self?.transcations = transcations.sorted{ $0.dateTime > $1.dateTime }
                completion?(transcations)
            }
            catch {
                debugPrint("decode failed")
                failure?()
                return
            }
        }
       
    }
    
    func selectedTranscation(at index: Int) -> Transcation {
        return (transcations?[index])!
    }
    
}
